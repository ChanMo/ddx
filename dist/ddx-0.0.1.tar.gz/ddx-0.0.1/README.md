# DDX (Django x Docker)

> 快速搭建基于Docker的Django项目

模板使用[django_boilerplate](https://github.com/ChanMo/django_boilerplate)

## 安装

```bash
$ sudo pip install ddx
```

## 使用

```bash
$ ddx new demo_com
```
